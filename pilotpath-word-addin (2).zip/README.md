
# PilotPath Word Add-in

This Microsoft Word Add-in integrates an AI-powered flight student dashboard into Word.

## Features
- AI quiz and feedback generation via GPT-4
- Settings tab for API key
- Multi-student dropdown with editable focus areas
- Word-based explanation simplifier

## Usage
1. Download the ZIP from this repo or the release
2. Open Word > Insert > My Add-ins > Shared Folder
3. Select the `manifest.xml` to sideload
4. Open the task pane via the add-in

## Development
Edit `taskpane.html` and reload your add-in.
